(function($){
	"use strict";

	$(window).load(function() {
		var $container = $('#fh5co-projects-feed'),
		containerWidth = $container.outerWidth();

		$container.masonry({
			itemSelector : '.fh5co-project',
			columnWidth: function( containerWidth ) {
				if( containerWidth <= 330 ) {
					return 310;
				} else {
					return 330;
				}
			},

			isAnimated: !Modernizr.csstransitions
		});
	});

})(window.jQuery);

// index.html 
const images = document.querySelectorAll('.image-container img');
let currentIndex = 0;

function changeImage() {
  images[currentIndex].classList.remove('active');
  
  currentIndex = (currentIndex + 1) % images.length;
  
  images[currentIndex].classList.add('active');
}

setInterval(changeImage, 2000);